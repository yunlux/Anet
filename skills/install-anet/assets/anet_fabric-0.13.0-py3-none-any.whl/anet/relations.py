from __future__ import annotations

import hashlib
import json
import secrets
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from .actors import is_actor_id, normalize_actor_kind, validate_actor_id
from .encoding import atomic_json
from .identity import PeerCard


RELATION_BOOK_VERSION = 7
RELATION_CIRCLES = (
    "public",
    "known",
    "collab",
    "friend",
    "close",
    "family",
)
ACTOR_STATES = frozenset({"active", "revoked"})
SUBJECT_STATES = frozenset({"active", "superseded"})
RELATIONSHIP_STATES = frozenset({"active", "dormant", "ended"})
MAX_LABEL_LENGTH = 128
MAX_EVIDENCE_LENGTH = 256
MAX_CONTEXT_LENGTH = 64
INTERACTION_DIRECTIONS = frozenset({"incoming", "outgoing"})
INTERACTION_FACETS = frozenset({"message", "task", "skill", "artifact"})
INTERACTION_OUTCOMES = frozenset(
    {
        "queued",
        "received",
        "submitted",
        "working",
        "input-required",
        "auth-required",
        "completed",
        "failed",
        "canceled",
        "rejected",
    }
)
SUBJECT_TRANSITION_TYPES = frozenset({"split", "merge", "supersede"})
ACTOR_PROOF_SCOPES = frozenset(
    {
        "cryptographic",
        "platform-observed",
        "bridge-attested",
        "operator-attested",
    }
)
SUGGESTION_DECISIONS = frozenset({"accepted", "rejected"})
RELATION_EVENT_DETAIL_FIELDS = {
    "actor.observed": frozenset({"actor_kind", "proof_scope"}),
    "actor.observation-refreshed": frozenset(
        {"actor_kind", "proof_scope"}
    ),
    "subject.actor-linked": frozenset({"confidence"}),
    "relationship.circle-set": frozenset({"circle", "confidence"}),
    "relationship.context-trust-set": frozenset(
        {"context", "estimate", "confidence"}
    ),
    "relationship.paused": frozenset({"state"}),
    "relationship.ended": frozenset({"state"}),
    "relationship.mutual-claim-withdrawn": frozenset(
        {"claim_id", "withdrawing_actor_id", "relationship_changed"}
    ),
}


def _now_ms(now: int | None) -> int:
    value = int(time.time() * 1000) if now is None else int(now)
    if value <= 0:
        raise ValueError("invalid relationship event time")
    return value


def _bounded_text(value: str, *, label: str, maximum: int) -> str:
    result = str(value).strip()
    if not result or len(result) > maximum:
        raise ValueError(f"invalid {label}")
    return result


def _confidence(value: int, *, label: str) -> int:
    result = int(value)
    if not 0 <= result <= 100:
        raise ValueError(f"invalid {label}")
    return result


def _unique_text(values: Iterable[str], *, label: str, maximum: int) -> tuple[str, ...]:
    return tuple(
        sorted({_bounded_text(value, label=label, maximum=maximum) for value in values})
    )


@dataclass(frozen=True)
class ActorProof:
    proof_type: str
    scope: str
    issuer_actor_id: str
    evidence_ref: str
    observed_ms: int

    def __post_init__(self) -> None:
        _bounded_text(
            self.proof_type,
            label="Actor proof type",
            maximum=MAX_CONTEXT_LENGTH,
        )
        if self.scope not in ACTOR_PROOF_SCOPES:
            raise ValueError("invalid Actor proof scope")
        validate_actor_id(self.issuer_actor_id)
        _bounded_text(
            self.evidence_ref,
            label="Actor proof evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        if self.observed_ms <= 0:
            raise ValueError("invalid Actor proof time")

    @property
    def key(self) -> tuple[str, str, str]:
        return (
            self.proof_type,
            self.scope,
            self.issuer_actor_id,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "proof_type": self.proof_type,
            "scope": self.scope,
            "issuer_actor_id": self.issuer_actor_id,
            "evidence_ref": self.evidence_ref,
            "observed_ms": self.observed_ms,
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "ActorProof":
        return cls(
            proof_type=str(value["proof_type"]),
            scope=str(value["scope"]),
            issuer_actor_id=str(value["issuer_actor_id"]),
            evidence_ref=str(value["evidence_ref"]),
            observed_ms=int(value["observed_ms"]),
        )


@dataclass(frozen=True)
class ActorObservation:
    actor_id: str
    actor_kind: str
    actor_label: str
    proof: ActorProof

    def __post_init__(self) -> None:
        validate_actor_id(self.actor_id)
        kind = normalize_actor_kind(self.actor_kind)
        if (self.actor_id.startswith("an1")) != (kind == "anet.node"):
            raise ValueError("Actor ID and kind use incompatible identity domains")
        if len(self.actor_label) > MAX_LABEL_LENGTH:
            raise ValueError("invalid Actor label")


@dataclass(frozen=True)
class ActorRecord:
    actor_id: str
    actor_kind: str
    actor_label: str
    state: str
    proofs: tuple[ActorProof, ...]
    evidence_refs: tuple[str, ...]
    first_seen_ms: int
    updated_ms: int

    def __post_init__(self) -> None:
        validate_actor_id(self.actor_id)
        kind = normalize_actor_kind(self.actor_kind)
        if (self.actor_id.startswith("an1")) != (kind == "anet.node"):
            raise ValueError("Actor ID and kind use incompatible identity domains")
        if len(self.actor_label) > MAX_LABEL_LENGTH:
            raise ValueError("invalid Actor label")
        if self.state not in ACTOR_STATES:
            raise ValueError("invalid Actor state")
        proof_keys = [proof.key for proof in self.proofs]
        if not self.proofs or len(proof_keys) != len(set(proof_keys)):
            raise ValueError("Actor must contain unique proof records")
        if self.first_seen_ms <= 0 or self.updated_ms < self.first_seen_ms:
            raise ValueError("invalid Actor observation time")

    def to_dict(self) -> dict[str, Any]:
        return {
            "actor_id": self.actor_id,
            "actor_kind": self.actor_kind,
            "actor_label": self.actor_label,
            "state": self.state,
            "proofs": [
                item.to_dict()
                for item in sorted(self.proofs, key=lambda item: item.key)
            ],
            "evidence_refs": list(self.evidence_refs),
            "first_seen_ms": self.first_seen_ms,
            "updated_ms": self.updated_ms,
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "ActorRecord":
        return cls(
            actor_id=str(value["actor_id"]),
            actor_kind=str(value["actor_kind"]),
            actor_label=str(value.get("actor_label", "")),
            state=str(value.get("state", "active")),
            proofs=tuple(
                ActorProof.from_dict(dict(item))
                for item in value.get("proofs", ())
            ),
            evidence_refs=_unique_text(
                value.get("evidence_refs", ()),
                label="Actor evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            first_seen_ms=int(value["first_seen_ms"]),
            updated_ms=int(value["updated_ms"]),
        )


@dataclass(frozen=True)
class SubjectActorLink:
    actor_id: str
    confidence: int
    evidence_refs: tuple[str, ...]
    updated_ms: int

    def __post_init__(self) -> None:
        validate_actor_id(self.actor_id)
        _confidence(self.confidence, label="Subject link confidence")
        if self.updated_ms <= 0:
            raise ValueError("invalid Subject link update time")

    def to_dict(self) -> dict[str, Any]:
        return {
            "actor_id": self.actor_id,
            "confidence": self.confidence,
            "evidence_refs": list(self.evidence_refs),
            "updated_ms": self.updated_ms,
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "SubjectActorLink":
        return cls(
            actor_id=str(value["actor_id"]),
            confidence=int(value["confidence"]),
            evidence_refs=_unique_text(
                value.get("evidence_refs", ()),
                label="Subject link evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            updated_ms=int(value["updated_ms"]),
        )


@dataclass(frozen=True)
class SubjectHypothesis:
    subject_ref: str
    state: str
    labels: tuple[str, ...]
    actor_links: tuple[SubjectActorLink, ...]
    evidence_refs: tuple[str, ...]
    updated_ms: int

    def __post_init__(self) -> None:
        if not self.subject_ref.startswith("subj_"):
            raise ValueError("invalid local Subject reference")
        if self.state not in SUBJECT_STATES:
            raise ValueError("invalid Subject hypothesis state")
        if not self.actor_links:
            raise ValueError("Subject hypothesis requires at least one Actor link")
        actor_ids = [link.actor_id for link in self.actor_links]
        if len(actor_ids) != len(set(actor_ids)):
            raise ValueError("Subject hypothesis contains a duplicate Actor link")
        if self.updated_ms <= 0:
            raise ValueError("invalid Subject hypothesis update time")

    @property
    def confidence(self) -> int:
        return max(link.confidence for link in self.actor_links)

    def to_dict(self) -> dict[str, Any]:
        return {
            "subject_ref": self.subject_ref,
            "state": self.state,
            "labels": list(self.labels),
            "actor_links": [
                link.to_dict()
                for link in sorted(self.actor_links, key=lambda item: item.actor_id)
            ],
            "evidence_refs": list(self.evidence_refs),
            "confidence": self.confidence,
            "updated_ms": self.updated_ms,
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "SubjectHypothesis":
        return cls(
            subject_ref=str(value["subject_ref"]),
            state=str(value.get("state", "active")),
            labels=_unique_text(
                value.get("labels", ()),
                label="Subject label",
                maximum=MAX_LABEL_LENGTH,
            ),
            actor_links=tuple(
                SubjectActorLink.from_dict(dict(item))
                for item in value.get("actor_links", ())
            ),
            evidence_refs=_unique_text(
                value.get("evidence_refs", ()),
                label="Subject evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            updated_ms=int(value["updated_ms"]),
        )


@dataclass(frozen=True)
class ContextTrust:
    context: str
    estimate: int
    confidence: int
    evidence_refs: tuple[str, ...]
    updated_ms: int

    def __post_init__(self) -> None:
        _bounded_text(
            self.context,
            label="trust context",
            maximum=MAX_CONTEXT_LENGTH,
        )
        _confidence(self.estimate, label="context trust estimate")
        _confidence(self.confidence, label="context trust confidence")
        if self.updated_ms <= 0:
            raise ValueError("invalid context trust update time")

    def to_dict(self) -> dict[str, Any]:
        return {
            "context": self.context,
            "estimate": self.estimate,
            "confidence": self.confidence,
            "evidence_refs": list(self.evidence_refs),
            "updated_ms": self.updated_ms,
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "ContextTrust":
        return cls(
            context=str(value["context"]),
            estimate=int(value["estimate"]),
            confidence=int(value["confidence"]),
            evidence_refs=_unique_text(
                value.get("evidence_refs", ()),
                label="context trust evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            updated_ms=int(value["updated_ms"]),
        )


@dataclass(frozen=True)
class RelationshipEstimate:
    subject_ref: str
    circle: str
    state: str
    relationship_labels: tuple[str, ...]
    relationship_confidence: int
    context_trust: tuple[ContextTrust, ...]
    evidence_refs: tuple[str, ...]
    updated_ms: int

    def __post_init__(self) -> None:
        if not self.subject_ref.startswith("subj_"):
            raise ValueError("invalid local Subject reference")
        if self.circle not in RELATION_CIRCLES:
            raise ValueError("invalid relationship circle")
        if self.state not in RELATIONSHIP_STATES:
            raise ValueError("invalid relationship state")
        _confidence(
            self.relationship_confidence,
            label="relationship confidence",
        )
        contexts = [item.context for item in self.context_trust]
        if len(contexts) != len(set(contexts)):
            raise ValueError("relationship contains a duplicate trust context")
        if self.updated_ms <= 0:
            raise ValueError("invalid relationship update time")

    def to_dict(self) -> dict[str, Any]:
        return {
            "subject_ref": self.subject_ref,
            "circle": self.circle,
            "state": self.state,
            "relationship_labels": list(self.relationship_labels),
            "relationship_confidence": self.relationship_confidence,
            "context_trust": [
                item.to_dict()
                for item in sorted(self.context_trust, key=lambda item: item.context)
            ],
            "evidence_refs": list(self.evidence_refs),
            "updated_ms": self.updated_ms,
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "RelationshipEstimate":
        return cls(
            subject_ref=str(value["subject_ref"]),
            circle=str(value["circle"]),
            state=str(value.get("state", "active")),
            relationship_labels=_unique_text(
                value.get("relationship_labels", ()),
                label="relationship label",
                maximum=MAX_LABEL_LENGTH,
            ),
            relationship_confidence=int(value["relationship_confidence"]),
            context_trust=tuple(
                ContextTrust.from_dict(dict(item))
                for item in value.get("context_trust", ())
            ),
            evidence_refs=_unique_text(
                value.get("evidence_refs", ()),
                label="relationship evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            updated_ms=int(value["updated_ms"]),
        )


@dataclass(frozen=True)
class RelationshipEvent:
    event_id: str
    event_type: str
    actor_id: str
    subject_ref: str
    evidence_ref: str
    observed_ms: int
    details: tuple[tuple[str, str | int], ...] = ()

    def __post_init__(self) -> None:
        if not self.event_id.startswith("revt_"):
            raise ValueError("invalid relationship event ID")
        _bounded_text(
            self.event_type,
            label="relationship event type",
            maximum=MAX_CONTEXT_LENGTH,
        )
        if self.actor_id and not is_actor_id(self.actor_id):
            raise ValueError("invalid relationship event Actor")
        if self.subject_ref and not self.subject_ref.startswith("subj_"):
            raise ValueError("invalid relationship event Subject")
        _bounded_text(
            self.evidence_ref,
            label="relationship event evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        if self.observed_ms <= 0:
            raise ValueError("invalid relationship event time")
        allowed = RELATION_EVENT_DETAIL_FIELDS.get(
            self.event_type,
            frozenset(),
        )
        keys = [key for key, _value in self.details]
        if (
            len(keys) != len(set(keys))
            or set(keys) - allowed
            or any(
                type(value) not in {str, int}
                for _key, value in self.details
            )
        ):
            raise ValueError("invalid relationship event details")
        detail_map = dict(self.details)
        if "confidence" in detail_map:
            _confidence(
                int(detail_map["confidence"]),
                label="relationship event confidence",
            )
        if "estimate" in detail_map:
            _confidence(
                int(detail_map["estimate"]),
                label="relationship event estimate",
            )
        if "circle" in detail_map and detail_map["circle"] not in RELATION_CIRCLES:
            raise ValueError("invalid relationship event circle")
        if "context" in detail_map:
            _bounded_text(
                str(detail_map["context"]),
                label="relationship event context",
                maximum=MAX_CONTEXT_LENGTH,
            )
        if "actor_kind" in detail_map:
            normalize_actor_kind(str(detail_map["actor_kind"]))
        if "proof_scope" in detail_map and detail_map["proof_scope"] not in (
            ACTOR_PROOF_SCOPES
        ):
            raise ValueError("invalid relationship event proof scope")

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_id": self.event_id,
            "event_type": self.event_type,
            "actor_id": self.actor_id,
            "subject_ref": self.subject_ref,
            "evidence_ref": self.evidence_ref,
            "observed_ms": self.observed_ms,
            "details": dict(self.details),
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "RelationshipEvent":
        raw_details = value.get("details", {})
        if not isinstance(raw_details, Mapping):
            raise ValueError("invalid relationship event details")
        if any(type(item) not in {str, int} for item in raw_details.values()):
            raise ValueError("invalid relationship event details")
        return cls(
            event_id=str(value["event_id"]),
            event_type=str(value["event_type"]),
            actor_id=str(value.get("actor_id", "")),
            subject_ref=str(value.get("subject_ref", "")),
            evidence_ref=str(value["evidence_ref"]),
            observed_ms=int(value["observed_ms"]),
            details=tuple(
                sorted(
                    (
                        str(key),
                        int(item) if isinstance(item, int) else str(item),
                    )
                    for key, item in raw_details.items()
                )
            ),
        )


@dataclass(frozen=True)
class SuggestionDecision:
    decision_id: str
    suggestion_id: str
    suggestion_type: str
    subject_ref: str
    decision: str
    rationale: str
    basis_hash: str
    suggestion_confidence: int
    proposed_circle: str
    context: str
    proposed_estimate: int | None
    applied: bool
    decided_ms: int

    def __post_init__(self) -> None:
        if not self.decision_id.startswith("rsd_"):
            raise ValueError("invalid suggestion decision ID")
        if not self.suggestion_id.startswith("rsg_"):
            raise ValueError("invalid relationship suggestion ID")
        _bounded_text(
            self.suggestion_type,
            label="relationship suggestion type",
            maximum=MAX_CONTEXT_LENGTH,
        )
        if not self.subject_ref.startswith("subj_"):
            raise ValueError("invalid suggestion decision Subject")
        if self.decision not in SUGGESTION_DECISIONS:
            raise ValueError("invalid suggestion decision")
        _bounded_text(
            self.rationale,
            label="suggestion decision rationale",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        if len(self.basis_hash) != 32:
            raise ValueError("invalid suggestion decision basis")
        _confidence(
            self.suggestion_confidence,
            label="suggestion decision confidence",
        )
        if self.proposed_circle and self.proposed_circle not in RELATION_CIRCLES:
            raise ValueError("invalid suggestion decision circle")
        if self.context:
            _bounded_text(
                self.context,
                label="suggestion decision context",
                maximum=MAX_CONTEXT_LENGTH,
            )
        if self.proposed_estimate is not None:
            _confidence(
                self.proposed_estimate,
                label="suggestion decision estimate",
            )
        if self.applied != (self.decision == "accepted"):
            raise ValueError("suggestion decision application mismatch")
        if self.decided_ms <= 0:
            raise ValueError("invalid suggestion decision time")

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision_id": self.decision_id,
            "suggestion_id": self.suggestion_id,
            "suggestion_type": self.suggestion_type,
            "subject_ref": self.subject_ref,
            "decision": self.decision,
            "rationale": self.rationale,
            "basis_hash": self.basis_hash,
            "suggestion_confidence": self.suggestion_confidence,
            "proposed_circle": self.proposed_circle,
            "context": self.context,
            "proposed_estimate": self.proposed_estimate,
            "applied": self.applied,
            "authorization_effect": "none",
            "decided_ms": self.decided_ms,
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "SuggestionDecision":
        applied = value.get("applied")
        if not isinstance(applied, bool):
            raise ValueError("invalid suggestion decision application")
        return cls(
            decision_id=str(value["decision_id"]),
            suggestion_id=str(value["suggestion_id"]),
            suggestion_type=str(value["suggestion_type"]),
            subject_ref=str(value["subject_ref"]),
            decision=str(value["decision"]),
            rationale=str(value["rationale"]),
            basis_hash=str(value["basis_hash"]),
            suggestion_confidence=int(value["suggestion_confidence"]),
            proposed_circle=str(value.get("proposed_circle", "")),
            context=str(value.get("context", "")),
            proposed_estimate=(
                None
                if value.get("proposed_estimate") is None
                else int(value["proposed_estimate"])
            ),
            applied=applied,
            decided_ms=int(value["decided_ms"]),
        )


@dataclass(frozen=True)
class InteractionEvidence:
    """Content-free evidence that a verified Actor interaction occurred."""

    interaction_id: str
    actor_id: str
    subject_ref: str
    direction: str
    facets: tuple[str, ...]
    context: str
    outcome: str
    evidence_ref: str
    occurred_ms: int

    def __post_init__(self) -> None:
        if not self.interaction_id.startswith("iev_"):
            raise ValueError("invalid interaction evidence ID")
        validate_actor_id(self.actor_id)
        if not self.subject_ref.startswith("subj_"):
            raise ValueError("invalid interaction Subject")
        if self.direction not in INTERACTION_DIRECTIONS:
            raise ValueError("invalid interaction direction")
        if not self.facets or any(
            facet not in INTERACTION_FACETS for facet in self.facets
        ):
            raise ValueError("invalid interaction facets")
        if len(self.facets) != len(set(self.facets)):
            raise ValueError("duplicate interaction facet")
        _bounded_text(
            self.context,
            label="interaction context",
            maximum=MAX_CONTEXT_LENGTH,
        )
        if self.outcome not in INTERACTION_OUTCOMES:
            raise ValueError("invalid interaction outcome")
        _bounded_text(
            self.evidence_ref,
            label="interaction evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        if self.occurred_ms <= 0:
            raise ValueError("invalid interaction time")

    @classmethod
    def create(
        cls,
        *,
        actor_id: str,
        subject_ref: str,
        direction: str,
        facets: Iterable[str],
        context: str,
        outcome: str,
        evidence_ref: str,
        occurred_ms: int,
    ) -> "InteractionEvidence":
        normalized_facets = tuple(sorted({str(item) for item in facets}))
        source = "\0".join(
            (
                str(actor_id),
                str(direction),
                str(evidence_ref),
            )
        ).encode("utf-8")
        interaction_id = "iev_" + hashlib.blake2s(
            source,
            digest_size=16,
            person=b"anet-iev",
        ).hexdigest()
        return cls(
            interaction_id=interaction_id,
            actor_id=str(actor_id),
            subject_ref=str(subject_ref),
            direction=str(direction),
            facets=normalized_facets,
            context=str(context),
            outcome=str(outcome),
            evidence_ref=str(evidence_ref),
            occurred_ms=int(occurred_ms),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "interaction_id": self.interaction_id,
            "actor_id": self.actor_id,
            "subject_ref": self.subject_ref,
            "direction": self.direction,
            "facets": list(self.facets),
            "context": self.context,
            "outcome": self.outcome,
            "evidence_ref": self.evidence_ref,
            "occurred_ms": self.occurred_ms,
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "InteractionEvidence":
        return cls(
            interaction_id=str(value["interaction_id"]),
            actor_id=str(value["actor_id"]),
            subject_ref=str(value["subject_ref"]),
            direction=str(value["direction"]),
            facets=tuple(str(item) for item in value.get("facets", ())),
            context=str(value["context"]),
            outcome=str(value["outcome"]),
            evidence_ref=str(value["evidence_ref"]),
            occurred_ms=int(value["occurred_ms"]),
        )


@dataclass(frozen=True)
class SubjectTransition:
    """Immutable lineage for one observer-local hypothesis revision."""

    transition_id: str
    transition_type: str
    source_subject_refs: tuple[str, ...]
    replacement_subject_refs: tuple[str, ...]
    confidence: int
    evidence_ref: str
    observed_ms: int

    def __post_init__(self) -> None:
        if not self.transition_id.startswith("strn_"):
            raise ValueError("invalid Subject transition ID")
        if self.transition_type not in SUBJECT_TRANSITION_TYPES:
            raise ValueError("invalid Subject transition type")
        if not self.source_subject_refs or not self.replacement_subject_refs:
            raise ValueError("Subject transition requires sources and replacements")
        refs = (*self.source_subject_refs, *self.replacement_subject_refs)
        if any(not item.startswith("subj_") for item in refs):
            raise ValueError("invalid Subject transition reference")
        if len(refs) != len(set(refs)):
            raise ValueError("Subject transition contains a duplicate reference")
        if self.transition_type == "split" and (
            len(self.source_subject_refs) != 1
            or len(self.replacement_subject_refs) < 2
        ):
            raise ValueError("split requires one source and multiple replacements")
        if self.transition_type == "merge" and (
            len(self.source_subject_refs) < 2
            or len(self.replacement_subject_refs) != 1
        ):
            raise ValueError("merge requires multiple sources and one replacement")
        if self.transition_type == "supersede" and (
            len(self.source_subject_refs) != 1
            or len(self.replacement_subject_refs) != 1
        ):
            raise ValueError("supersede requires one source and one replacement")
        _confidence(self.confidence, label="Subject transition confidence")
        _bounded_text(
            self.evidence_ref,
            label="Subject transition evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        if self.observed_ms <= 0:
            raise ValueError("invalid Subject transition time")

    def to_dict(self) -> dict[str, Any]:
        return {
            "transition_id": self.transition_id,
            "transition_type": self.transition_type,
            "source_subject_refs": list(self.source_subject_refs),
            "replacement_subject_refs": list(self.replacement_subject_refs),
            "confidence": self.confidence,
            "evidence_ref": self.evidence_ref,
            "observed_ms": self.observed_ms,
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "SubjectTransition":
        return cls(
            transition_id=str(value["transition_id"]),
            transition_type=str(value["transition_type"]),
            source_subject_refs=tuple(
                str(item) for item in value.get("source_subject_refs", ())
            ),
            replacement_subject_refs=tuple(
                str(item) for item in value.get("replacement_subject_refs", ())
            ),
            confidence=int(value["confidence"]),
            evidence_ref=str(value["evidence_ref"]),
            observed_ms=int(value["observed_ms"]),
        )


@dataclass(frozen=True)
class RelationshipRecord:
    """Compatibility projection for one Actor through its primary Subject."""

    subject_ref: str
    actor_id: str
    actor_kind: str
    actor_label: str
    proof_scopes: tuple[str, ...]
    circle: str
    state: str
    relationship_labels: tuple[str, ...]
    subject_confidence: int
    relationship_confidence: int
    evidence_refs: tuple[str, ...]
    updated_ms: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "subject_ref": self.subject_ref,
            "actor_id": self.actor_id,
            "actor_kind": self.actor_kind,
            "actor_label": self.actor_label,
            "proof_scopes": list(self.proof_scopes),
            "circle": self.circle,
            "state": self.state,
            "relationship_labels": list(self.relationship_labels),
            "subject_confidence": self.subject_confidence,
            "relationship_confidence": self.relationship_confidence,
            "evidence_refs": list(self.evidence_refs),
            "updated_ms": self.updated_ms,
        }


class RelationshipBook:
    """Observer-local Actor facts, Subject hypotheses, and relationship estimates."""

    def __init__(self, path: Path, *, own_actor_id: str) -> None:
        self.path = Path(path)
        self.own_actor_id = validate_actor_id(own_actor_id)
        self._actors: dict[str, ActorRecord] = {}
        self._subjects: dict[str, SubjectHypothesis] = {}
        self._relationships: dict[str, RelationshipEstimate] = {}
        self._events: list[RelationshipEvent] = []
        self._interactions: dict[str, InteractionEvidence] = {}
        self._transitions: list[SubjectTransition] = []
        self._suggestion_decisions: dict[str, SuggestionDecision] = {}
        self.reload()

    def reload(self) -> None:
        if not self.path.exists():
            self._actors = {}
            self._subjects = {}
            self._relationships = {}
            self._events = []
            self._interactions = {}
            self._transitions = []
            self._suggestion_decisions = {}
            return
        value = json.loads(self.path.read_text(encoding="utf-8"))
        version = int(value.get("version", 0))
        if version == 1:
            self._load_v1(value)
            return
        if version not in {2, 3, 4, 5, 6, RELATION_BOOK_VERSION}:
            raise ValueError("unsupported relationship book version")
        actors = {
            item.actor_id: item
            for item in (
                self._actor_from_dict(dict(item), version=version)
                for item in value.get("actors", ())
            )
        }
        subjects = {
            item.subject_ref: item
            for item in (
                SubjectHypothesis.from_dict(dict(value))
                for value in value.get("subjects", ())
            )
        }
        relationships = {
            item.subject_ref: item
            for item in (
                RelationshipEstimate.from_dict(dict(value))
                for value in value.get("relationships", ())
            )
        }
        events = [
            RelationshipEvent.from_dict(dict(item)) for item in value.get("events", ())
        ]
        interactions = {
            item.interaction_id: item
            for item in (
                InteractionEvidence.from_dict(dict(item))
                for item in value.get("interactions", ())
            )
        }
        transitions = [
            SubjectTransition.from_dict(dict(item))
            for item in value.get("subject_transitions", ())
        ]
        suggestion_decisions = {
            item.suggestion_id: item
            for item in (
                SuggestionDecision.from_dict(dict(item))
                for item in value.get("suggestion_decisions", ())
            )
        }
        self._validate_model(
            actors,
            subjects,
            relationships,
            events,
            interactions,
            transitions,
            suggestion_decisions,
        )
        self._actors = actors
        self._subjects = subjects
        self._relationships = relationships
        self._events = events
        self._interactions = interactions
        self._transitions = transitions
        self._suggestion_decisions = suggestion_decisions

    @staticmethod
    def _actor_from_dict(value: dict[str, Any], *, version: int) -> ActorRecord:
        if version >= 5:
            return ActorRecord.from_dict(value)
        actor_id = str(value["actor_id"])
        first_seen_ms = int(value["first_seen_ms"])
        evidence_refs = _unique_text(
            value.get("evidence_refs", ()),
            label="Actor evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        migration_evidence = (
            evidence_refs[0] if evidence_refs else f"migration:relations-v{version}"
        )
        return ActorRecord(
            actor_id=actor_id,
            actor_kind="anet.node",
            actor_label=str(value.get("actor_label", "")),
            state=str(value.get("state", "active")),
            proofs=(
                ActorProof(
                    proof_type="anet.peer-card",
                    scope="cryptographic",
                    issuer_actor_id=actor_id,
                    evidence_ref=migration_evidence,
                    observed_ms=first_seen_ms,
                ),
            ),
            evidence_refs=evidence_refs or (migration_evidence,),
            first_seen_ms=first_seen_ms,
            updated_ms=int(value["updated_ms"]),
        )

    def _load_v1(self, value: dict[str, Any]) -> None:
        actors: dict[str, ActorRecord] = {}
        subjects: dict[str, SubjectHypothesis] = {}
        relationships: dict[str, RelationshipEstimate] = {}
        for raw in value.get("relationships", ()):
            actor_id = str(raw["actor_id"])
            updated_ms = int(raw["updated_ms"])
            evidence_refs = _unique_text(
                raw.get("evidence_refs", ()),
                label="relationship evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            )
            subject_ref = str(raw["subject_ref"])
            actors[actor_id] = ActorRecord(
                actor_id=actor_id,
                actor_kind="anet.node",
                actor_label=str(raw.get("actor_label", ""))[:MAX_LABEL_LENGTH],
                state=(
                    "revoked"
                    if str(raw.get("state", "active")) == "revoked"
                    else "active"
                ),
                proofs=(
                    ActorProof(
                        proof_type="anet.peer-card",
                        scope="cryptographic",
                        issuer_actor_id=actor_id,
                        evidence_ref=(
                            evidence_refs[0]
                            if evidence_refs
                            else "migration:relations-v1"
                        ),
                        observed_ms=updated_ms,
                    ),
                ),
                evidence_refs=evidence_refs or ("migration:relations-v1",),
                first_seen_ms=updated_ms,
                updated_ms=updated_ms,
            )
            subjects[subject_ref] = SubjectHypothesis(
                subject_ref=subject_ref,
                state="active",
                labels=(),
                actor_links=(
                    SubjectActorLink(
                        actor_id=actor_id,
                        confidence=int(raw["subject_confidence"]),
                        evidence_refs=evidence_refs,
                        updated_ms=updated_ms,
                    ),
                ),
                evidence_refs=evidence_refs,
                updated_ms=updated_ms,
            )
            relationships[subject_ref] = RelationshipEstimate(
                subject_ref=subject_ref,
                circle=str(raw["circle"]),
                state=(
                    "ended"
                    if str(raw.get("state", "active")) == "revoked"
                    else "active"
                ),
                relationship_labels=_unique_text(
                    raw.get("relationship_labels", ()),
                    label="relationship label",
                    maximum=MAX_LABEL_LENGTH,
                ),
                relationship_confidence=int(raw["relationship_confidence"]),
                context_trust=(),
                evidence_refs=evidence_refs,
                updated_ms=updated_ms,
            )
        self._validate_model(actors, subjects, relationships, [])
        self._actors = actors
        self._subjects = subjects
        self._relationships = relationships
        self._events = []
        self._interactions = {}
        self._transitions = []
        self._suggestion_decisions = {}

    def _validate_model(
        self,
        actors: dict[str, ActorRecord],
        subjects: dict[str, SubjectHypothesis],
        relationships: dict[str, RelationshipEstimate],
        events: list[RelationshipEvent],
        interactions: dict[str, InteractionEvidence] | None = None,
        transitions: list[SubjectTransition] | None = None,
        suggestion_decisions: dict[str, SuggestionDecision] | None = None,
    ) -> None:
        if self.own_actor_id in actors:
            raise ValueError("relationship book contains the local Actor")
        for actor in actors.values():
            for proof in actor.proofs:
                if (
                    proof.issuer_actor_id != self.own_actor_id
                    and proof.issuer_actor_id != actor.actor_id
                    and proof.issuer_actor_id not in actors
                ):
                    raise ValueError("Actor proof references an unknown issuer")
        linked_actors: set[str] = set()
        for subject in subjects.values():
            for link in subject.actor_links:
                if link.actor_id not in actors:
                    raise ValueError("Subject hypothesis references an unknown Actor")
                linked_actors.add(link.actor_id)
        if linked_actors != set(actors):
            raise ValueError("every observed Actor must belong to a Subject hypothesis")
        active_linked_actors = {
            link.actor_id
            for subject in subjects.values()
            if subject.state == "active"
            for link in subject.actor_links
        }
        if active_linked_actors != set(actors):
            raise ValueError("every observed Actor must have an active Subject hypothesis")
        if set(relationships) != set(subjects):
            raise ValueError("every Subject hypothesis must have one relationship")
        event_ids = [event.event_id for event in events]
        if len(event_ids) != len(set(event_ids)):
            raise ValueError("relationship book contains a duplicate event")
        for interaction in (interactions or {}).values():
            if interaction.actor_id not in actors:
                raise ValueError("interaction references an unknown Actor")
            subject = subjects.get(interaction.subject_ref)
            if subject is None:
                raise ValueError("interaction references an unknown Subject")
            if interaction.actor_id not in {
                link.actor_id for link in subject.actor_links
            }:
                raise ValueError("interaction Actor is not linked to its Subject")
        transition_values = transitions or []
        transition_ids = [item.transition_id for item in transition_values]
        if len(transition_ids) != len(set(transition_ids)):
            raise ValueError("relationship book contains a duplicate transition")
        transition_sources: set[str] = set()
        transition_replacements: set[str] = set()
        lineage: dict[str, set[str]] = {}
        for transition in transition_values:
            for source_ref in transition.source_subject_refs:
                if source_ref in transition_sources:
                    raise ValueError("Subject hypothesis has multiple outgoing transitions")
                transition_sources.add(source_ref)
                source = subjects.get(source_ref)
                if source is None:
                    raise ValueError("transition references an unknown source Subject")
                if source.state != "superseded":
                    raise ValueError("transition source Subject is not superseded")
                lineage.setdefault(source_ref, set()).update(
                    transition.replacement_subject_refs
                )
            for replacement_ref in transition.replacement_subject_refs:
                if replacement_ref in transition_replacements:
                    raise ValueError(
                        "Subject hypothesis has multiple incoming transitions"
                    )
                transition_replacements.add(replacement_ref)
                replacement = subjects.get(replacement_ref)
                if replacement is None:
                    raise ValueError(
                        "transition references an unknown replacement Subject"
                    )
        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(subject_ref: str) -> None:
            if subject_ref in visiting:
                raise ValueError("Subject transition lineage contains a cycle")
            if subject_ref in visited:
                return
            visiting.add(subject_ref)
            for replacement_ref in lineage.get(subject_ref, ()):
                visit(replacement_ref)
            visiting.remove(subject_ref)
            visited.add(subject_ref)

        for subject_ref in lineage:
            visit(subject_ref)
        decisions = suggestion_decisions or {}
        if set(decisions) != {
            item.suggestion_id for item in decisions.values()
        }:
            raise ValueError("suggestion decision key mismatch")
        decision_ids = [item.decision_id for item in decisions.values()]
        if len(decision_ids) != len(set(decision_ids)):
            raise ValueError("relationship book contains a duplicate decision")
        for decision in decisions.values():
            if decision.subject_ref not in subjects:
                raise ValueError("suggestion decision references an unknown Subject")

    def save(self) -> None:
        atomic_json(
            self.path,
            {
                "version": RELATION_BOOK_VERSION,
                "observer_actor_id": self.own_actor_id,
                "actors": [self._actors[key].to_dict() for key in sorted(self._actors)],
                "subjects": [
                    self._subjects[key].to_dict() for key in sorted(self._subjects)
                ],
                "relationships": [
                    self._relationships[key].to_dict()
                    for key in sorted(self._relationships)
                ],
                "events": [event.to_dict() for event in self._events],
                "interactions": [
                    self._interactions[key].to_dict()
                    for key in sorted(self._interactions)
                ],
                "subject_transitions": [
                    item.to_dict() for item in self._transitions
                ],
                "suggestion_decisions": [
                    self._suggestion_decisions[key].to_dict()
                    for key in sorted(self._suggestion_decisions)
                ],
            },
            private=True,
        )

    def _append_event(
        self,
        event_type: str,
        *,
        evidence_ref: str,
        actor_id: str = "",
        subject_ref: str = "",
        now: int,
        details: Mapping[str, str | int] | None = None,
    ) -> RelationshipEvent:
        event = RelationshipEvent(
            event_id=f"revt_{secrets.token_hex(12)}",
            event_type=event_type,
            actor_id=actor_id,
            subject_ref=subject_ref,
            evidence_ref=evidence_ref,
            observed_ms=now,
            details=tuple(sorted((details or {}).items())),
        )
        self._events.append(event)
        return event

    def observe_actor(
        self,
        card: PeerCard,
        *,
        evidence_ref: str,
        subject_confidence: int = 50,
        now: int | None = None,
    ) -> SubjectHypothesis:
        card.verify()
        if card.node_id == self.own_actor_id:
            raise ValueError("cannot observe the local Actor as a peer")
        evidence = _bounded_text(
            evidence_ref,
            label="Actor evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        confidence = _confidence(
            subject_confidence,
            label="initial Subject confidence",
        )
        current = _now_ms(now)
        return self.observe_typed_actor(
            ActorObservation(
                actor_id=card.node_id,
                actor_kind="anet.node",
                actor_label=card.label[:MAX_LABEL_LENGTH],
                proof=ActorProof(
                    proof_type="anet.peer-card",
                    scope="cryptographic",
                    issuer_actor_id=card.node_id,
                    evidence_ref=evidence,
                    observed_ms=current,
                ),
            ),
            subject_confidence=confidence,
            now=current,
        )

    def observe_typed_actor(
        self,
        observation: ActorObservation,
        *,
        subject_confidence: int = 50,
        now: int | None = None,
    ) -> SubjectHypothesis:
        """Record an attributed action source without asserting a real Subject.

        Adapters must supply a scoped proof. This Module stores only the opaque
        Actor reference and evidence metadata; it neither verifies platform
        credentials itself nor transfers trust from the proof issuer.
        """

        if observation.actor_id == self.own_actor_id:
            raise ValueError("cannot observe the local Actor as a peer")
        if (
            observation.proof.issuer_actor_id != self.own_actor_id
            and observation.proof.issuer_actor_id != observation.actor_id
            and observation.proof.issuer_actor_id not in self._actors
        ):
            raise ValueError("Actor proof issuer is not known to this observer")
        evidence = observation.proof.evidence_ref
        confidence = _confidence(
            subject_confidence,
            label="initial Subject confidence",
        )
        current = _now_ms(now)
        if observation.proof.observed_ms > current:
            raise ValueError("Actor proof occurs after the observation")
        actor = self._actors.get(observation.actor_id)
        if actor is None:
            actor = ActorRecord(
                actor_id=observation.actor_id,
                actor_kind=observation.actor_kind,
                actor_label=observation.actor_label,
                state="active",
                proofs=(observation.proof,),
                evidence_refs=(evidence,),
                first_seen_ms=current,
                updated_ms=current,
            )
            self._actors[observation.actor_id] = actor
            subject_ref = f"subj_{secrets.token_hex(8)}"
            subject = SubjectHypothesis(
                subject_ref=subject_ref,
                state="active",
                labels=(),
                actor_links=(
                    SubjectActorLink(
                        actor_id=observation.actor_id,
                        confidence=confidence,
                        evidence_refs=(evidence,),
                        updated_ms=current,
                    ),
                ),
                evidence_refs=(evidence,),
                updated_ms=current,
            )
            self._subjects[subject_ref] = subject
            self._relationships[subject_ref] = RelationshipEstimate(
                subject_ref=subject_ref,
                circle="public",
                state="active",
                relationship_labels=(),
                relationship_confidence=0,
                context_trust=(),
                evidence_refs=(evidence,),
                updated_ms=current,
            )
            self._append_event(
                "actor.observed",
                actor_id=observation.actor_id,
                subject_ref=subject_ref,
                evidence_ref=evidence,
                now=current,
                details={
                    "actor_kind": observation.actor_kind,
                    "proof_scope": observation.proof.scope,
                },
            )
            self.save()
            return subject

        if actor.actor_kind != observation.actor_kind:
            raise ValueError("Actor observation changes the Actor kind")
        proofs = {proof.key: proof for proof in actor.proofs}
        proof_is_new = observation.proof.key not in proofs
        proofs.setdefault(observation.proof.key, observation.proof)
        label = observation.actor_label or actor.actor_label
        if (
            not proof_is_new
            and label == actor.actor_label
        ):
            subject = self.primary_subject(observation.actor_id)
            if subject is None:
                raise ValueError("observed Actor has no Subject hypothesis")
            return subject
        self._actors[observation.actor_id] = ActorRecord(
            actor_id=actor.actor_id,
            actor_kind=actor.actor_kind,
            actor_label=label,
            state=actor.state,
            proofs=tuple(proofs.values()),
            evidence_refs=_unique_text(
                (
                    *actor.evidence_refs,
                    *(
                        (evidence,)
                        if proof_is_new or label != actor.actor_label
                        else ()
                    ),
                ),
                label="Actor evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            first_seen_ms=actor.first_seen_ms,
            updated_ms=current,
        )
        subject = self.primary_subject(observation.actor_id)
        if subject is None:
            raise ValueError("observed Actor has no Subject hypothesis")
        self._append_event(
            "actor.observation-refreshed",
            actor_id=observation.actor_id,
            subject_ref=subject.subject_ref,
            evidence_ref=evidence,
            now=current,
            details={
                "actor_kind": observation.actor_kind,
                "proof_scope": observation.proof.scope,
            },
        )
        self.save()
        return subject

    def has_interaction(self, interaction_id: str) -> bool:
        return str(interaction_id) in self._interactions

    def record_interaction(
        self,
        evidence: InteractionEvidence,
    ) -> bool:
        """Persist one idempotent, content-free interaction observation."""

        if evidence.interaction_id in self._interactions:
            return False
        if evidence.actor_id not in self._actors:
            raise KeyError(f"unknown Actor: {evidence.actor_id}")
        subject = self._subjects.get(evidence.subject_ref)
        if subject is None:
            raise KeyError(f"unknown Subject hypothesis: {evidence.subject_ref}")
        if evidence.actor_id not in {
            link.actor_id for link in subject.actor_links
        }:
            raise ValueError("interaction Actor is not linked to its Subject")
        self._interactions[evidence.interaction_id] = evidence
        self._append_event(
            "interaction.observed",
            actor_id=evidence.actor_id,
            subject_ref=evidence.subject_ref,
            evidence_ref=evidence.evidence_ref,
            now=evidence.occurred_ms,
        )
        self.save()
        return True

    @staticmethod
    def _replacement_relationship(
        subject_ref: str,
        *,
        source: RelationshipEstimate | None,
        evidence_ref: str,
        now: int,
    ) -> RelationshipEstimate:
        if source is None:
            return RelationshipEstimate(
                subject_ref=subject_ref,
                circle="known",
                state="active",
                relationship_labels=(),
                relationship_confidence=25,
                context_trust=(),
                evidence_refs=(evidence_ref,),
                updated_ms=now,
            )
        return RelationshipEstimate(
            subject_ref=subject_ref,
            circle=source.circle,
            state=source.state,
            relationship_labels=source.relationship_labels,
            relationship_confidence=source.relationship_confidence,
            context_trust=source.context_trust,
            evidence_refs=_unique_text(
                (*source.evidence_refs, evidence_ref),
                label="relationship evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            updated_ms=now,
        )

    def _commit_subject_transition(
        self,
        transition: SubjectTransition,
        replacements: tuple[SubjectHypothesis, ...],
        *,
        inheritance: dict[str, str],
    ) -> SubjectTransition:
        subjects = dict(self._subjects)
        relationships = dict(self._relationships)
        events = list(self._events)
        for source_ref in transition.source_subject_refs:
            source = subjects[source_ref]
            subjects[source_ref] = SubjectHypothesis(
                subject_ref=source.subject_ref,
                state="superseded",
                labels=source.labels,
                actor_links=source.actor_links,
                evidence_refs=_unique_text(
                    (*source.evidence_refs, transition.evidence_ref),
                    label="Subject evidence reference",
                    maximum=MAX_EVIDENCE_LENGTH,
                ),
                updated_ms=transition.observed_ms,
            )
            relationship = relationships[source_ref]
            relationships[source_ref] = RelationshipEstimate(
                subject_ref=relationship.subject_ref,
                circle=relationship.circle,
                state=(
                    "dormant"
                    if relationship.state == "active"
                    else relationship.state
                ),
                relationship_labels=relationship.relationship_labels,
                relationship_confidence=relationship.relationship_confidence,
                context_trust=relationship.context_trust,
                evidence_refs=_unique_text(
                    (*relationship.evidence_refs, transition.evidence_ref),
                    label="relationship evidence reference",
                    maximum=MAX_EVIDENCE_LENGTH,
                ),
                updated_ms=transition.observed_ms,
            )
            events.append(
                RelationshipEvent(
                    event_id=f"revt_{secrets.token_hex(12)}",
                    event_type=f"subject.{transition.transition_type}",
                    actor_id="",
                    subject_ref=source_ref,
                    evidence_ref=transition.evidence_ref,
                    observed_ms=transition.observed_ms,
                )
            )

        for replacement in replacements:
            subjects[replacement.subject_ref] = replacement
            inherited_ref = inheritance.get(replacement.subject_ref)
            relationships[replacement.subject_ref] = self._replacement_relationship(
                replacement.subject_ref,
                source=(
                    self._relationships[inherited_ref]
                    if inherited_ref is not None
                    else None
                ),
                evidence_ref=transition.evidence_ref,
                now=transition.observed_ms,
            )

        transitions = [*self._transitions, transition]
        self._validate_model(
            self._actors,
            subjects,
            relationships,
            events,
            self._interactions,
            transitions,
        )
        self._subjects = subjects
        self._relationships = relationships
        self._events = events
        self._transitions = transitions
        self.save()
        return transition

    def supersede_subject(
        self,
        subject_ref: str,
        *,
        confidence: int,
        evidence_ref: str,
        labels: Iterable[str] = (),
        now: int | None = None,
    ) -> SubjectTransition:
        source_ref = _bounded_text(
            subject_ref,
            label="Subject reference",
            maximum=128,
        )
        source = self._subjects.get(source_ref)
        if source is None:
            raise KeyError(f"unknown Subject hypothesis: {source_ref}")
        if source.state != "active":
            raise ValueError("cannot supersede an inactive Subject hypothesis")
        transition_confidence = _confidence(
            confidence,
            label="Subject transition confidence",
        )
        evidence = _bounded_text(
            evidence_ref,
            label="Subject transition evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        current = _now_ms(now)
        replacement_ref = f"subj_{secrets.token_hex(8)}"
        replacement = SubjectHypothesis(
            subject_ref=replacement_ref,
            state="active",
            labels=_unique_text(
                (*source.labels, *labels),
                label="Subject label",
                maximum=MAX_LABEL_LENGTH,
            ),
            actor_links=tuple(
                SubjectActorLink(
                    actor_id=link.actor_id,
                    confidence=link.confidence,
                    evidence_refs=_unique_text(
                        (*link.evidence_refs, evidence),
                        label="Subject link evidence reference",
                        maximum=MAX_EVIDENCE_LENGTH,
                    ),
                    updated_ms=current,
                )
                for link in source.actor_links
            ),
            evidence_refs=_unique_text(
                (*source.evidence_refs, evidence),
                label="Subject evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            updated_ms=current,
        )
        transition = SubjectTransition(
            transition_id=f"strn_{secrets.token_hex(12)}",
            transition_type="supersede",
            source_subject_refs=(source_ref,),
            replacement_subject_refs=(replacement_ref,),
            confidence=transition_confidence,
            evidence_ref=evidence,
            observed_ms=current,
        )
        return self._commit_subject_transition(
            transition,
            (replacement,),
            inheritance={replacement_ref: source_ref},
        )

    def merge_subjects(
        self,
        subject_refs: Iterable[str],
        *,
        confidence: int,
        evidence_ref: str,
        inherit_subject_ref: str = "",
        labels: Iterable[str] = (),
        now: int | None = None,
    ) -> SubjectTransition:
        source_refs = tuple(dict.fromkeys(str(item).strip() for item in subject_refs))
        if len(source_refs) < 2:
            raise ValueError("merge requires at least two Subject hypotheses")
        sources: list[SubjectHypothesis] = []
        for source_ref in source_refs:
            source = self._subjects.get(source_ref)
            if source is None:
                raise KeyError(f"unknown Subject hypothesis: {source_ref}")
            if source.state != "active":
                raise ValueError("cannot merge an inactive Subject hypothesis")
            sources.append(source)
        inherited_ref = str(inherit_subject_ref).strip()
        if inherited_ref and inherited_ref not in source_refs:
            raise ValueError("merge inheritance must name one source Subject")
        transition_confidence = _confidence(
            confidence,
            label="Subject transition confidence",
        )
        evidence = _bounded_text(
            evidence_ref,
            label="Subject transition evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        current = _now_ms(now)
        links: dict[str, SubjectActorLink] = {}
        for source in sources:
            for link in source.actor_links:
                previous = links.get(link.actor_id)
                links[link.actor_id] = SubjectActorLink(
                    actor_id=link.actor_id,
                    confidence=max(
                        link.confidence,
                        previous.confidence if previous is not None else 0,
                    ),
                    evidence_refs=_unique_text(
                        (
                            *(previous.evidence_refs if previous is not None else ()),
                            *link.evidence_refs,
                            evidence,
                        ),
                        label="Subject link evidence reference",
                        maximum=MAX_EVIDENCE_LENGTH,
                    ),
                    updated_ms=current,
                )
        replacement_ref = f"subj_{secrets.token_hex(8)}"
        replacement = SubjectHypothesis(
            subject_ref=replacement_ref,
            state="active",
            labels=_unique_text(
                (
                    *(label for source in sources for label in source.labels),
                    *labels,
                ),
                label="Subject label",
                maximum=MAX_LABEL_LENGTH,
            ),
            actor_links=tuple(links.values()),
            evidence_refs=_unique_text(
                (
                    *(
                        ref
                        for source in sources
                        for ref in source.evidence_refs
                    ),
                    evidence,
                ),
                label="Subject evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            updated_ms=current,
        )
        transition = SubjectTransition(
            transition_id=f"strn_{secrets.token_hex(12)}",
            transition_type="merge",
            source_subject_refs=source_refs,
            replacement_subject_refs=(replacement_ref,),
            confidence=transition_confidence,
            evidence_ref=evidence,
            observed_ms=current,
        )
        return self._commit_subject_transition(
            transition,
            (replacement,),
            inheritance=(
                {replacement_ref: inherited_ref}
                if inherited_ref
                else {}
            ),
        )

    def split_subject(
        self,
        subject_ref: str,
        groups: Iterable[Iterable[str]],
        *,
        confidence: int,
        evidence_ref: str,
        inherit_group: int | None = None,
        labels: Iterable[str] = (),
        now: int | None = None,
    ) -> SubjectTransition:
        source_ref = _bounded_text(
            subject_ref,
            label="Subject reference",
            maximum=128,
        )
        source = self._subjects.get(source_ref)
        if source is None:
            raise KeyError(f"unknown Subject hypothesis: {source_ref}")
        if source.state != "active":
            raise ValueError("cannot split an inactive Subject hypothesis")
        normalized_groups = tuple(
            tuple(dict.fromkeys(str(actor).strip() for actor in group))
            for group in groups
        )
        if len(normalized_groups) < 2 or any(not group for group in normalized_groups):
            raise ValueError("split requires at least two non-empty Actor groups")
        flattened = tuple(actor for group in normalized_groups for actor in group)
        if len(flattened) != len(set(flattened)):
            raise ValueError("split Actor groups overlap")
        source_actors = {link.actor_id for link in source.actor_links}
        if set(flattened) != source_actors:
            raise ValueError("split groups must exactly partition the source Actors")
        if inherit_group is not None and not 0 <= inherit_group < len(normalized_groups):
            raise ValueError("split inheritance group is out of range")
        transition_confidence = _confidence(
            confidence,
            label="Subject transition confidence",
        )
        evidence = _bounded_text(
            evidence_ref,
            label="Subject transition evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        current = _now_ms(now)
        source_links = {link.actor_id: link for link in source.actor_links}
        replacements: list[SubjectHypothesis] = []
        for group in normalized_groups:
            replacement_ref = f"subj_{secrets.token_hex(8)}"
            replacements.append(
                SubjectHypothesis(
                    subject_ref=replacement_ref,
                    state="active",
                    labels=_unique_text(
                        (*source.labels, *labels),
                        label="Subject label",
                        maximum=MAX_LABEL_LENGTH,
                    ),
                    actor_links=tuple(
                        SubjectActorLink(
                            actor_id=actor_id,
                            confidence=source_links[actor_id].confidence,
                            evidence_refs=_unique_text(
                                (*source_links[actor_id].evidence_refs, evidence),
                                label="Subject link evidence reference",
                                maximum=MAX_EVIDENCE_LENGTH,
                            ),
                            updated_ms=current,
                        )
                        for actor_id in group
                    ),
                    evidence_refs=_unique_text(
                        (*source.evidence_refs, evidence),
                        label="Subject evidence reference",
                        maximum=MAX_EVIDENCE_LENGTH,
                    ),
                    updated_ms=current,
                )
            )
        transition = SubjectTransition(
            transition_id=f"strn_{secrets.token_hex(12)}",
            transition_type="split",
            source_subject_refs=(source_ref,),
            replacement_subject_refs=tuple(
                item.subject_ref for item in replacements
            ),
            confidence=transition_confidence,
            evidence_ref=evidence,
            observed_ms=current,
        )
        inheritance = (
            {replacements[inherit_group].subject_ref: source_ref}
            if inherit_group is not None
            else {}
        )
        return self._commit_subject_transition(
            transition,
            tuple(replacements),
            inheritance=inheritance,
        )

    def link_actor(
        self,
        actor_id: str,
        subject_ref: str,
        *,
        confidence: int,
        evidence_ref: str,
        now: int | None = None,
    ) -> SubjectHypothesis:
        actor = _bounded_text(
            actor_id,
            label="Actor ID",
            maximum=256,
        )
        subject_key = _bounded_text(
            subject_ref,
            label="Subject reference",
            maximum=128,
        )
        if actor not in self._actors:
            raise KeyError(f"unknown Actor: {actor}")
        subject = self._subjects.get(subject_key)
        if subject is None:
            raise KeyError(f"unknown Subject hypothesis: {subject_key}")
        if subject.state != "active":
            raise ValueError("cannot link an Actor to a superseded Subject")
        link_confidence = _confidence(
            confidence,
            label="Subject link confidence",
        )
        evidence = _bounded_text(
            evidence_ref,
            label="Subject link evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        current = _now_ms(now)
        links = {link.actor_id: link for link in subject.actor_links}
        previous = links.get(actor)
        links[actor] = SubjectActorLink(
            actor_id=actor,
            confidence=link_confidence,
            evidence_refs=_unique_text(
                (
                    *(previous.evidence_refs if previous is not None else ()),
                    evidence,
                ),
                label="Subject link evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            updated_ms=current,
        )
        updated = SubjectHypothesis(
            subject_ref=subject.subject_ref,
            state=subject.state,
            labels=subject.labels,
            actor_links=tuple(links.values()),
            evidence_refs=_unique_text(
                (*subject.evidence_refs, evidence),
                label="Subject evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            updated_ms=current,
        )
        self._subjects[subject_key] = updated
        self._append_event(
            "subject.actor-linked",
            actor_id=actor,
            subject_ref=subject_key,
            evidence_ref=evidence,
            now=current,
            details={"confidence": link_confidence},
        )
        self.save()
        return updated

    def set_circle(
        self,
        subject_ref: str,
        circle: str,
        *,
        confidence: int,
        evidence_ref: str,
        labels: Iterable[str] = (),
        now: int | None = None,
    ) -> RelationshipEstimate:
        subject_key = _bounded_text(
            subject_ref,
            label="Subject reference",
            maximum=128,
        )
        if subject_key not in self._subjects:
            raise KeyError(f"unknown Subject hypothesis: {subject_key}")
        if circle not in RELATION_CIRCLES:
            raise ValueError("invalid relationship circle")
        relationship_confidence = _confidence(
            confidence,
            label="relationship confidence",
        )
        evidence = _bounded_text(
            evidence_ref,
            label="relationship evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        current = _now_ms(now)
        existing = self._relationships[subject_key]
        updated = RelationshipEstimate(
            subject_ref=subject_key,
            circle=circle,
            state="active",
            relationship_labels=_unique_text(
                (*existing.relationship_labels, *labels),
                label="relationship label",
                maximum=MAX_LABEL_LENGTH,
            ),
            relationship_confidence=relationship_confidence,
            context_trust=existing.context_trust,
            evidence_refs=_unique_text(
                (*existing.evidence_refs, evidence),
                label="relationship evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            updated_ms=current,
        )
        self._relationships[subject_key] = updated
        self._append_event(
            "relationship.circle-set",
            subject_ref=subject_key,
            evidence_ref=evidence,
            now=current,
            details={
                "circle": circle,
                "confidence": relationship_confidence,
            },
        )
        self.save()
        return updated

    def set_context_trust(
        self,
        subject_ref: str,
        context: str,
        *,
        estimate: int,
        confidence: int,
        evidence_ref: str,
        now: int | None = None,
    ) -> RelationshipEstimate:
        subject_key = _bounded_text(
            subject_ref,
            label="Subject reference",
            maximum=128,
        )
        relationship = self._relationships.get(subject_key)
        if relationship is None:
            raise KeyError(f"unknown Subject hypothesis: {subject_key}")
        context_name = _bounded_text(
            context,
            label="trust context",
            maximum=MAX_CONTEXT_LENGTH,
        )
        evidence = _bounded_text(
            evidence_ref,
            label="context trust evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        current = _now_ms(now)
        contexts = {item.context: item for item in relationship.context_trust}
        previous = contexts.get(context_name)
        contexts[context_name] = ContextTrust(
            context=context_name,
            estimate=_confidence(
                estimate,
                label="context trust estimate",
            ),
            confidence=_confidence(
                confidence,
                label="context trust confidence",
            ),
            evidence_refs=_unique_text(
                (
                    *(previous.evidence_refs if previous is not None else ()),
                    evidence,
                ),
                label="context trust evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            updated_ms=current,
        )
        updated = RelationshipEstimate(
            subject_ref=relationship.subject_ref,
            circle=relationship.circle,
            state=relationship.state,
            relationship_labels=relationship.relationship_labels,
            relationship_confidence=relationship.relationship_confidence,
            context_trust=tuple(contexts.values()),
            evidence_refs=_unique_text(
                (*relationship.evidence_refs, evidence),
                label="relationship evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            updated_ms=current,
        )
        self._relationships[subject_key] = updated
        self._append_event(
            "relationship.context-trust-set",
            subject_ref=subject_key,
            evidence_ref=evidence,
            now=current,
            details={
                "context": context_name,
                "estimate": contexts[context_name].estimate,
                "confidence": contexts[context_name].confidence,
            },
        )
        self.save()
        return updated

    def end_relationship(
        self,
        subject_ref: str,
        *,
        evidence_ref: str,
        now: int | None = None,
    ) -> RelationshipEstimate:
        """End one local relationship estimate without rewriting its Subject."""

        return self._set_relationship_state(
            subject_ref,
            state="ended",
            event_type="relationship.ended",
            evidence_ref=evidence_ref,
            now=now,
        )

    def pause_relationship(
        self,
        subject_ref: str,
        *,
        evidence_ref: str,
        now: int | None = None,
    ) -> RelationshipEstimate:
        """Mark one local relationship as dormant without rewriting its Subject."""

        return self._set_relationship_state(
            subject_ref,
            state="dormant",
            event_type="relationship.paused",
            evidence_ref=evidence_ref,
            now=now,
        )

    def _set_relationship_state(
        self,
        subject_ref: str,
        *,
        state: str,
        event_type: str,
        evidence_ref: str,
        now: int | None,
    ) -> RelationshipEstimate:
        if state not in {"dormant", "ended"}:
            raise ValueError("relationship state transition must be dormant or ended")

        subject_key = _bounded_text(
            subject_ref,
            label="Subject reference",
            maximum=128,
        )
        relationship = self._relationships.get(subject_key)
        if relationship is None:
            raise KeyError(f"unknown Subject hypothesis: {subject_key}")
        if relationship.state == state:
            return relationship
        if state == "dormant" and relationship.state == "ended":
            raise ValueError(
                "cannot pause an ended relationship; use relation-circle to reactivate it"
            )
        evidence = _bounded_text(
            evidence_ref,
            label="relationship state evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        current = _now_ms(now)
        updated = RelationshipEstimate(
            subject_ref=relationship.subject_ref,
            circle=relationship.circle,
            state=state,
            relationship_labels=relationship.relationship_labels,
            relationship_confidence=relationship.relationship_confidence,
            context_trust=relationship.context_trust,
            evidence_refs=_unique_text(
                (*relationship.evidence_refs, evidence),
                label="relationship evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            updated_ms=current,
        )
        self._relationships[subject_key] = updated
        self._append_event(
            event_type,
            subject_ref=subject_key,
            evidence_ref=evidence,
            now=current,
            details={"state": state},
        )
        self.save()
        return updated

    def suggestion_decision(
        self,
        suggestion_id: str,
    ) -> SuggestionDecision | None:
        return self._suggestion_decisions.get(str(suggestion_id))

    def suggestion_decisions(
        self,
        *,
        subject_ref: str = "",
    ) -> tuple[SuggestionDecision, ...]:
        selected = str(subject_ref).strip()
        if selected and selected not in self._subjects:
            raise KeyError(f"unknown Subject hypothesis: {selected}")
        return tuple(
            sorted(
                (
                    item
                    for item in self._suggestion_decisions.values()
                    if not selected or item.subject_ref == selected
                ),
                key=lambda item: (item.decided_ms, item.decision_id),
            )
        )

    def decide_suggestion(
        self,
        suggestion: dict[str, Any],
        decision: str,
        *,
        rationale: str,
        now: int | None = None,
    ) -> SuggestionDecision:
        """Atomically record and, when accepted, apply one current suggestion."""

        outcome = str(decision)
        if outcome not in SUGGESTION_DECISIONS:
            raise ValueError("suggestion decision must be accepted or rejected")
        suggestion_id = _bounded_text(
            str(suggestion.get("suggestion_id", "")),
            label="relationship suggestion ID",
            maximum=64,
        )
        if not suggestion_id.startswith("rsg_"):
            raise ValueError("invalid relationship suggestion ID")
        existing = self._suggestion_decisions.get(suggestion_id)
        if existing is not None:
            if existing.decision != outcome:
                raise ValueError("relationship suggestion already has another decision")
            return existing

        suggestion_type = _bounded_text(
            str(suggestion.get("suggestion_type", "")),
            label="relationship suggestion type",
            maximum=MAX_CONTEXT_LENGTH,
        )
        subject_ref = _bounded_text(
            str(suggestion.get("subject_ref", "")),
            label="Subject reference",
            maximum=128,
        )
        subject = self._subjects.get(subject_ref)
        if subject is None or subject.state != "active":
            raise ValueError("relationship suggestion Subject is not active")
        reason = _bounded_text(
            rationale,
            label="suggestion decision rationale",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        basis_hash = str(suggestion.get("basis_hash", ""))
        confidence = _confidence(
            int(suggestion.get("confidence", -1)),
            label="relationship suggestion confidence",
        )
        proposed_circle = str(suggestion.get("proposed_circle", ""))
        context = str(suggestion.get("context", ""))
        raw_estimate = suggestion.get("proposed_estimate")
        proposed_estimate = (
            None if raw_estimate is None else _confidence(
                int(raw_estimate),
                label="relationship suggestion estimate",
            )
        )
        if len(basis_hash) != 32:
            raise ValueError("invalid relationship suggestion basis")
        if suggestion_type == "circle.advance":
            if proposed_circle != "collab" or context or proposed_estimate is not None:
                raise ValueError("unsupported circle suggestion")
        elif suggestion_type == "context-trust.review":
            if proposed_circle or context != "task.delivery" or proposed_estimate is None:
                raise ValueError("unsupported contextual trust suggestion")
        else:
            raise ValueError("unsupported relationship suggestion")

        current = _now_ms(now)
        evidence = f"suggestion:{suggestion_id}"
        if outcome == "accepted":
            relationship = self._relationships[subject_ref]
            if suggestion_type == "circle.advance":
                self._relationships[subject_ref] = RelationshipEstimate(
                    subject_ref=subject_ref,
                    circle=proposed_circle,
                    state="active",
                    relationship_labels=relationship.relationship_labels,
                    relationship_confidence=confidence,
                    context_trust=relationship.context_trust,
                    evidence_refs=_unique_text(
                        (*relationship.evidence_refs, evidence),
                        label="relationship evidence reference",
                        maximum=MAX_EVIDENCE_LENGTH,
                    ),
                    updated_ms=current,
                )
                self._append_event(
                    "relationship.circle-set",
                    subject_ref=subject_ref,
                    evidence_ref=evidence,
                    now=current,
                    details={
                        "circle": proposed_circle,
                        "confidence": confidence,
                    },
                )
            else:
                contexts = {
                    item.context: item for item in relationship.context_trust
                }
                previous = contexts.get(context)
                contexts[context] = ContextTrust(
                    context=context,
                    estimate=proposed_estimate,
                    confidence=confidence,
                    evidence_refs=_unique_text(
                        (
                            *(
                                previous.evidence_refs
                                if previous is not None
                                else ()
                            ),
                            evidence,
                        ),
                        label="context trust evidence reference",
                        maximum=MAX_EVIDENCE_LENGTH,
                    ),
                    updated_ms=current,
                )
                self._relationships[subject_ref] = RelationshipEstimate(
                    subject_ref=subject_ref,
                    circle=relationship.circle,
                    state=relationship.state,
                    relationship_labels=relationship.relationship_labels,
                    relationship_confidence=relationship.relationship_confidence,
                    context_trust=tuple(contexts.values()),
                    evidence_refs=_unique_text(
                        (*relationship.evidence_refs, evidence),
                        label="relationship evidence reference",
                        maximum=MAX_EVIDENCE_LENGTH,
                    ),
                    updated_ms=current,
                )
                self._append_event(
                    "relationship.context-trust-set",
                    subject_ref=subject_ref,
                    evidence_ref=evidence,
                    now=current,
                    details={
                        "context": context,
                        "estimate": proposed_estimate,
                        "confidence": confidence,
                    },
                )

        decision_id = "rsd_" + hashlib.blake2s(
            f"{self.own_actor_id}:{suggestion_id}".encode("utf-8"),
            digest_size=16,
            person=b"anetrsdi",
        ).hexdigest()
        record = SuggestionDecision(
            decision_id=decision_id,
            suggestion_id=suggestion_id,
            suggestion_type=suggestion_type,
            subject_ref=subject_ref,
            decision=outcome,
            rationale=reason,
            basis_hash=basis_hash,
            suggestion_confidence=confidence,
            proposed_circle=proposed_circle,
            context=context,
            proposed_estimate=proposed_estimate,
            applied=outcome == "accepted",
            decided_ms=current,
        )
        self._suggestion_decisions[suggestion_id] = record
        self._append_event(
            f"relationship.suggestion-{outcome}",
            subject_ref=subject_ref,
            evidence_ref=evidence,
            now=current,
        )
        self.save()
        return record

    def confirm_friend(
        self,
        card: PeerCard,
        *,
        evidence_ref: str,
        now: int | None = None,
    ) -> RelationshipRecord:
        current = _now_ms(now)
        subject = self.observe_actor(
            card,
            evidence_ref=evidence_ref,
            now=current,
        )
        existing = self._relationships[subject.subject_ref]
        circle = (
            existing.circle
            if RELATION_CIRCLES.index(existing.circle)
            >= RELATION_CIRCLES.index("friend")
            else "friend"
        )
        self.set_circle(
            subject.subject_ref,
            circle,
            confidence=100,
            labels=("relationship:friend",),
            evidence_ref=evidence_ref,
            now=current,
        )
        result = self.get(card.node_id)
        if result is None:
            raise RuntimeError("friend confirmation did not create a relationship")
        return result

    def confirm_mutual_relationship(
        self,
        card: PeerCard,
        circle: str,
        *,
        evidence_ref: str,
        labels: Iterable[str] = (),
        now: int | None = None,
    ) -> RelationshipRecord:
        if circle not in RELATION_CIRCLES[1:]:
            raise ValueError("mutual relationship circle must be known or closer")
        current = _now_ms(now)
        subject = self.primary_subject(card.node_id)
        if subject is not None:
            existing = self._relationships[subject.subject_ref]
            if evidence_ref in existing.evidence_refs:
                result = self.get(card.node_id)
                if result is None:
                    raise RuntimeError("mutual relationship projection is missing")
                return result
        subject = self.observe_actor(
            card,
            evidence_ref=evidence_ref,
            now=current,
        )
        existing = self._relationships[subject.subject_ref]
        projected_circle = (
            existing.circle
            if RELATION_CIRCLES.index(existing.circle)
            >= RELATION_CIRCLES.index(circle)
            else circle
        )
        self.set_circle(
            subject.subject_ref,
            projected_circle,
            confidence=100,
            labels=(
                *labels,
                "relationship:mutual",
                f"relationship:mutual:{circle}",
            ),
            evidence_ref=evidence_ref,
            now=current,
        )
        result = self.get(card.node_id)
        if result is None:
            raise RuntimeError("mutual relationship claim was not projected")
        return result

    def record_mutual_relationship_withdrawal(
        self,
        card: PeerCard,
        *,
        claim_id: str,
        withdrawing_actor_id: str,
        evidence_ref: str,
        now: int | None = None,
    ) -> RelationshipRecord:
        """Record portable-claim withdrawal without rewriting this estimate.

        A withdrawal is evidence that a participant no longer stands behind one
        shared claim. The observer still decides its own circle and contextual
        trust, so neither is changed here.
        """
        card.verify()
        current = _now_ms(now)
        evidence = _bounded_text(
            evidence_ref,
            label="relationship claim withdrawal evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        subject = self.primary_subject(card.node_id)
        if subject is None:
            subject = self.observe_actor(
                card,
                evidence_ref=evidence,
                now=current,
            )
        if any(
            event.event_type == "relationship.mutual-claim-withdrawn"
            and event.evidence_ref == evidence
            for event in self._events
        ):
            result = self.get(card.node_id)
            if result is None:
                raise RuntimeError("relationship claim withdrawal projection is missing")
            return result
        self._append_event(
            "relationship.mutual-claim-withdrawn",
            actor_id=card.node_id,
            subject_ref=subject.subject_ref,
            evidence_ref=evidence,
            now=current,
            details={
                "claim_id": str(claim_id),
                "withdrawing_actor_id": str(withdrawing_actor_id),
                "relationship_changed": 0,
            },
        )
        self.save()
        result = self.get(card.node_id)
        if result is None:
            raise RuntimeError("relationship claim withdrawal projection is missing")
        return result

    def revoke_actor(
        self,
        actor_id: str,
        *,
        evidence_ref: str,
        now: int | None = None,
    ) -> RelationshipRecord | None:
        actor_key = str(actor_id).strip()
        actor = self._actors.get(actor_key)
        if actor is None:
            return None
        if actor.state == "revoked":
            return self.get(actor_key)
        evidence = _bounded_text(
            evidence_ref,
            label="Actor revocation evidence reference",
            maximum=MAX_EVIDENCE_LENGTH,
        )
        current = _now_ms(now)
        self._actors[actor_key] = ActorRecord(
            actor_id=actor.actor_id,
            actor_kind=actor.actor_kind,
            actor_label=actor.actor_label,
            state="revoked",
            proofs=actor.proofs,
            evidence_refs=_unique_text(
                (*actor.evidence_refs, evidence),
                label="Actor evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            first_seen_ms=actor.first_seen_ms,
            updated_ms=current,
        )
        subject = self.primary_subject(actor_key)
        self._append_event(
            "actor.revoked",
            actor_id=actor_key,
            subject_ref=subject.subject_ref if subject is not None else "",
            evidence_ref=evidence,
            now=current,
        )
        self.save()
        return self.get(actor_key)

    def primary_subject(self, actor_id: str) -> SubjectHypothesis | None:
        actor_key = str(actor_id)
        candidates = [
            (link.confidence, subject.updated_ms, subject.subject_ref, subject)
            for subject in self._subjects.values()
            if subject.state == "active"
            for link in subject.actor_links
            if link.actor_id == actor_key
        ]
        if not candidates:
            return None
        return max(candidates, key=lambda item: (item[0], item[1], item[2]))[3]

    def actor(self, actor_id: str) -> ActorRecord | None:
        """Return one locally observed Actor without exposing mutable state."""

        return self._actors.get(validate_actor_id(actor_id))

    def subject(self, subject_ref: str) -> SubjectHypothesis | None:
        return self._subjects.get(str(subject_ref))

    def relationship(self, subject_ref: str) -> RelationshipEstimate | None:
        return self._relationships.get(str(subject_ref))

    def snapshot(self) -> dict[str, Any]:
        return {
            "version": RELATION_BOOK_VERSION,
            "observer_actor_id": self.own_actor_id,
            "actors": [self._actors[key].to_dict() for key in sorted(self._actors)],
            "subjects": [
                self._subjects[key].to_dict() for key in sorted(self._subjects)
            ],
            "relationships": [
                self._relationships[key].to_dict()
                for key in sorted(self._relationships)
            ],
            "events": [event.to_dict() for event in self._events],
            "interactions": [
                self._interactions[key].to_dict()
                for key in sorted(self._interactions)
            ],
            "interaction_stats": self.interaction_stats(),
            "subject_transitions": [
                item.to_dict() for item in self._transitions
            ],
            "suggestion_decisions": [
                self._suggestion_decisions[key].to_dict()
                for key in sorted(self._suggestion_decisions)
            ],
        }

    def interaction_stats(self) -> list[dict[str, Any]]:
        """Return a derived summary; counts are evidence, never trust scores."""

        grouped: dict[
            tuple[str, str, str],
            dict[str, Any],
        ] = {}
        for evidence in self._interactions.values():
            for facet in evidence.facets:
                key = (evidence.subject_ref, evidence.context, facet)
                item = grouped.setdefault(
                    key,
                    {
                        "subject_ref": evidence.subject_ref,
                        "context": evidence.context,
                        "facet": facet,
                        "incoming": 0,
                        "outgoing": 0,
                        "outcomes": {},
                        "first_ms": evidence.occurred_ms,
                        "last_ms": evidence.occurred_ms,
                    },
                )
                item[evidence.direction] += 1
                outcomes = item["outcomes"]
                outcomes[evidence.outcome] = outcomes.get(evidence.outcome, 0) + 1
                item["first_ms"] = min(item["first_ms"], evidence.occurred_ms)
                item["last_ms"] = max(item["last_ms"], evidence.occurred_ms)
        return [
            {
                **item,
                "outcomes": dict(sorted(item["outcomes"].items())),
            }
            for _, item in sorted(grouped.items())
        ]

    def all(self) -> tuple[RelationshipRecord, ...]:
        result = []
        for actor_id in sorted(self._actors):
            record = self.get(actor_id)
            if record is not None:
                result.append(record)
        return tuple(result)

    def get(self, actor_id: str) -> RelationshipRecord | None:
        actor = self._actors.get(str(actor_id))
        if actor is None:
            return None
        subject = self.primary_subject(actor.actor_id)
        if subject is None:
            return None
        link = next(
            item for item in subject.actor_links if item.actor_id == actor.actor_id
        )
        relationship = self._relationships[subject.subject_ref]
        return RelationshipRecord(
            subject_ref=subject.subject_ref,
            actor_id=actor.actor_id,
            actor_kind=actor.actor_kind,
            actor_label=actor.actor_label,
            proof_scopes=tuple(
                sorted({proof.scope for proof in actor.proofs})
            ),
            circle=relationship.circle,
            state=relationship.state,
            relationship_labels=relationship.relationship_labels,
            subject_confidence=link.confidence,
            relationship_confidence=relationship.relationship_confidence,
            evidence_refs=_unique_text(
                (
                    *actor.evidence_refs,
                    *subject.evidence_refs,
                    *relationship.evidence_refs,
                ),
                label="relationship evidence reference",
                maximum=MAX_EVIDENCE_LENGTH,
            ),
            updated_ms=max(
                actor.updated_ms,
                subject.updated_ms,
                relationship.updated_ms,
            ),
        )
